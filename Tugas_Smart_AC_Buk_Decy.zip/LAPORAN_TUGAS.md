# LAPORAN TUGAS PRAKTIKUM MIKROKONTROLER & SISTEM TERTANAM
## SISTEM OTOMASI PENGATUR SUHU RUANGAN (SMART AC) MANDIRI BERBASIS ARDUINO UNO DAN SENSOR DHT22 (NON-IoT)

**Disusun untuk Memenuhi Tugas Mata Pelajaran:** Pemrograman Sistem Tertanam & Mikrokontroler  
**Kelas:** XI TELKOM  
**Dosen / Pengampu:** Buk Decy  

---

### RINGKASAN PROYEK
Proyek ini mengimplementasikan sistem otomasi pengatur suhu ruangan (*Air Conditioner* cerdas) mandiri (*standalone / non-IoT*) berbasis mikrokontroler **Arduino Uno R3** dan sensor suhu digital **DHT22**. Sistem ini beroperasi secara otonom tanpa memerlukan koneksi internet, WiFi, maupun cloud eksternal. Pengguna mengatur target suhu ruangan (*setpoint*) secara fisik menggunakan **Potensiometer** putar ($16^\circ\text{C} - 30^\circ\text{C}$). Mikrokontroler membandingkan suhu aktual dari sensor DHT22 dengan target suhu yang ditentukan, lalu secara proporsional mengendalikan aktuator AC nyata: **Relay 5V** (saklar kompresor utama) dan **Motor DC Blower AC** (pengatur kecepatan hembusan udara dengan penentuan RPM presisi: 0 hingga 1.500 RPM). Seluruh status sistem ditampilkan secara lokal pada layar **LCD 16x2 I2C** dan indikator suara **Buzzer**.

---

## BAB I: PENDAHULUAN

### 1.1 Latar Belakang
Konsumsi energi pendingin ruangan (AC) menyumbang porsi besar pada penggunaan listrik gedung dan rumah tangga. Sering kali AC dibiarkan menyala pada pengaturan suhu terendah secara terus-menerus tanpa penyesuaian dinamis terhadap suhu ruangan yang sebenarnya. Diperlukan sebuah sistem pengatur suhu cerdas berbasis IoT yang mampu:
1. Memantau suhu dan kelembapan ruangan secara akurat.
2. Memudahkan pengguna mengatur target suhu melalui antarmuka web modern (tanpa aplikasi khusus).
3. Melakukan kontrol otomatis terhadap intensitas pendinginan agar ruangan tetap nyaman sekaligus menghemat energi.

### 1.2 Rumusan Masalah
1. Bagaimana mengintegrasikan mikrokontroler ESP32 dengan sensor DHT22 untuk pemantauan suhu dan kelembapan ruangan secara berkala?
2. Bagaimana membangun Web Server lokal di dalam ESP32 yang menyediakan kontrol target suhu via slider dan input numerik yang sinkron?
3. Bagaimana merancang algoritma kendali otomatis untuk mengubah status dan kecepatan pendinginan AC berdasarkan selisih suhu aktual dan suhu target?

### 1.3 Tujuan
1. Merealisasikan sistem otomasi iklim ruangan cerdas berbasis ESP32.
2. Menyediakan antarmuka pengguna berbasis web responsif tanpa ketergantungan pada cloud pihak ketiga.
3. Menampilkan status kerja AC secara real-time melalui indikator visual (LCD dan LED).

---

## BAB II: PERANCANGAN SISTEM

### 2.1 Arsitektur Sistem (Blok Diagram & Visualisasi 3D)

![Visualisasi 3D Kamar Tidur Cerdas Futuristik](file:///d:/tugas%20buk%20decy/gambar_3d_futuristic_bedroom.jpg)
*Gambar 2.1: Render Arsitektur 3D Kamar Tidur Gaming Futuristik dengan AC Hitam Pintar, Pencahayaan Ambient Neon RGB, Box IoT Dinding, dan Antarmuka Kontrol Layar.*

![Prototipe Perangkat Keras Box Akrilik](file:///d:/tugas%20buk%20decy/foto_alat_hardware_akrilik.jpg)
*Gambar 2.2: Foto Prototipe Fisik Sistem: Sensor DHT22, Box Kontroler Akrilik Transparan (ESP32, Modul Relay 2-Channel, & LCD Display), serta Aktuator Unit AC Miniatur Hitam Matte.*

```
+------------------------+
|      Sensor DHT22      |  ---> Membaca Suhu & Kelembapan
+------------------------+
            |
            v  (GPIO 15)
+--------------------------------------------------------------+
|                      Mikrokontroler ESP32                    |
|  - Web Server (Port 80)                                      |
|  - Algoritma Komparasi Suhu: Delta T = T_ruang - T_target     |
|  - Kontrol State AC (HIGH / MED / STANDBY)                   |
+--------------------------------------------------------------+
       |                  |                          |
       v (I2C)            v (GPIO 2 & 4)             v (WiFi HTTP)
+--------------+    +------------------+    +-----------------------+
|  LCD 16x2    |    |  LED Indikator   |    |  Web Dashboard        |
|  (Tampilan)  |    |  (Simulasi AC)   |    |  (Slider & Input Box) |
+--------------+    +------------------+    +-----------------------+
```

### 2.2 Alokasi Pin Hardware (Wiring Table)

#### A. Opsi 1: Berbasis Arduino Uno R3 (Dengan Aktuator AC Lengkap)
| Komponen / Aktuator | Pin Komponen | Pin Arduino Uno | Fungsi Utama |
|---|---|---|---|
| **Sensor DHT22** | DATA / OUT | Pin Digital 2 | Membaca suhu & kelembapan digital |
| | VCC / GND | 5V / GND | Catu daya sensor |
| **LCD 16x2 I2C** | SDA / SCL | Pin A4 / Pin A5 | Menampilkan suhu aktual, target, & status AC |
| | VCC / GND | 5V / GND | Catu daya modul I2C |
| **Potensiometer (Slider)** | Kaki Tengah | Pin Analog A0 | Pengatur target suhu fisik (16°C - 30°C) |
| **Motor DC Blower AC** | PWM (Signal) | Pin Digital ~6 (PWM) | **Aktuator Utama Blower AC**: Pengatur kecepatan putaran RPM dinamis (0 - 1500 RPM) |
| **Relay Module 5V** | IN (Signal) | Pin Digital 7 | **Aktuator Kompresor AC**: Saklar daya utama pendingin |
| **Piezo Buzzer** | Positif (+) | Pin Digital 8 | Suara konfirmasi "Beep" saat suhu diubah |

#### B. Opsi 2: Berbasis ESP32 (Dengan Web Server WiFi)
| Modul / Komponen | Pin Modul | Pin ESP32 | Keterangan |
|---|---|---|---|
| **DHT22** | DATA | GPIO 15 | Sinyal Data Sensor Digital |
| **LCD 16x2 (I2C)** | SDA / SCL | GPIO 21 / GPIO 22 | Komunikasi Layar I2C |
| **LED Biru (AC On)** | Anoda (+) | GPIO 2 | Indikator Pendinginan Aktif |
| **LED Hijau (Standby)** | Anoda (+) | GPIO 4 | Indikator Suhu Tercapai |

---

## BAB III: ALGORITMA DAN LOGIKA KENDALI

### 3.1 Konsep Kendali Adaptif Berbasis Okupansi (Makin Banyak Orang, AC Makin Dingin)
Sistem pendingin ini menerapkan paradigma **Occupancy-Based Adaptive Climate Control**. Konsep ini didasari oleh prinsip termodinamika bahwa setiap tubuh manusia mengeluarkan kalor disipasi metabolisme rata-rata sebesar $\approx 100\text{ Watt}$. Kehadiran banyak orang dalam satu ruangan tertutup (seperti ruang rapat atau ruang kelas) menyebabkan akumulasi panas yang signifikan serta peningkatan kelembapan dari hembusan napas.

Untuk mempertahankan kenyamanan termal (*thermal comfort*) tanpa intervensi manual, sistem menghitung **Target Suhu Adaptif ($T_{\text{target}}$)** secara otomatis menggunakan persamaan:

$$T_{\text{target}} = \max\left(18.0^\circ\text{C}, \, T_{\text{dasar}} - (k \times N_{\text{orang}})\right)$$

Dengan parameter perancangan:
* $T_{\text{dasar}} = 24.0^\circ\text{C}$ (Suhu kenyamanan dasar saat ruangan santai).
* $k = 0.6^\circ\text{C}/\text{orang}$ (Koefisien adaptasi kalor per orang).
* $N_{\text{orang}}$: Jumlah peserta rapat yang berada di dalam ruangan (0 s/d 10 orang, disimulasikan melalui Potensiometer Pin A0).

#### Tabel Skenario Logika Adaptif Okupansi:

| Jumlah Orang ($N$) | Target Adaptif ($T_{\text{target}}$) | Mode AC | PWM Motor | Kecepatan Blower (RPM) | Relay Kompresor |
| :---: | :---: | :---: | :---: | :---: | :---: |
| **0 Orang** | $25.0^\circ\text{C}$ (Eco) | **STANDBY** | 0 (0%) | **0 RPM** | **OFF (Hemat Energi)** |
| **1 - 2 Orang** | $23.4 - 22.8^\circ\text{C}$ | **LOW COOL** | 95 (~37%) | **600 RPM** | **ON** |
| **3 - 5 Orang** | $22.2 - 21.0^\circ\text{C}$ | **MED COOL** | 145 (~57%) | **900 RPM** | **ON** |
| **6 - 8 Orang** | $20.4 - 19.2^\circ\text{C}$ | **HIGH COOL** | 205 (~80%) | **1.200 RPM** | **ON** |
| **9 - 10 Orang** | **$18.0^\circ\text{C}$ (Maksimal)** | **TURBO COOL**| 255 (100%) | **1.500 RPM** | **ON** |

### 3.2 Algoritma Penentuan Kecepatan Motor Blower (RPM)
Pengaturan putaran motor blower dan aktivasi kompresor dievaluasi berdasarkan selisih antara suhu aktual sensor DHT22 ($T_{\text{aktual}}$) terhadap target adaptif ($T_{\text{target}}$):
$$\Delta T = T_{\text{aktual}} - T_{\text{target}}$$

Aturan keputusan (*decision rules*):
1. **$\Delta T \ge 4.0^\circ\text{C}$ atau $N \ge 9$ (Beban Maksimal) $\rightarrow$ TURBO COOL**:
   - Kecepatan Motor: **1.500 RPM** (PWM 255 / 100%).
   - Relay Kompresor: **ON**.
   - Tampilan LCD: `10Org Tgt:18.0C` / `R:29.0C 1500RPM`.
2. **$2.0^\circ\text{C} \le \Delta T < 4.0^\circ\text{C}$ atau $N \ge 6$ (Beban Tinggi) $\rightarrow$ HIGH COOL**:
   - Kecepatan Motor: **1.200 RPM** (PWM 205 / ~80%).
   - Relay Kompresor: **ON**.
   - Tampilan LCD: ` 6Org Tgt:20.4C` / `R:27.5C 1200RPM`.
3. **$0.0^\circ\text{C} < \Delta T < 2.0^\circ\text{C}$ atau $N \ge 3$ (Beban Sedang) $\rightarrow$ MED COOL**:
   - Kecepatan Motor: **900 RPM** (PWM 145 / ~57%).
   - Relay Kompresor: **ON**.
   - Tampilan LCD: ` 4Org Tgt:21.6C` / `R:25.0C  900RPM`.
4. **$N = 0$ (Ruangan Kosong) $\rightarrow$ STANDBY**:
   - Kecepatan Motor: **0 RPM** (PWM 0).
   - Relay Kompresor: **OFF** (Hemat Energi).
   - Tampilan LCD: `0 Org  [STANDBY]` / `R:23.0C    0 RPM`.

### 3.2 Analisis Kurva Respon Transien Menggunakan MATLAB

Untuk memvalidasi respon dinamik sistem pendinginan ruangan secara ilmiah, dilakukan pemodelan matematis menggunakan **MATLAB R2024b** berdasarkan persamaan diferensial termal orde satu:
$$T(t) = T_{\text{set}} + (T_{\text{awal}} - T_{\text{set}}) \cdot e^{-t/\tau}$$

Dengan parameter $T_{\text{awal}} = 32.0^\circ\text{C}$, $T_{\text{set}} = 24.0^\circ\text{C}$, dan konstanta waktu ruangan $\tau = 45\text{ detik}$.

![Grafik Respon Dinamis MATLAB](file:///d:/tugas%20buk%20decy/grafik_respon_matlab.png)
*Gambar 3.1: Respon Dinamis Transien Suhu Ruang $T(t)$, Kecepatan Motor Blower AC (RPM), dan Status Relay Kompresor (Simulasi MATLAB).*

![Karakteristik Kendali RPM MATLAB](file:///d:/tugas%20buk%20decy/grafik_karakteristik_rpm.png)
*Gambar 3.2: Karakteristik Fungsi Transfer Kecepatan Motor Blower (RPM) dan Sinyal PWM terhadap Selisih Suhu $\Delta T$ (Simulasi MATLAB).*

Dari Gambar 3.1 dan 3.2 dapat disimpulkan:
- Respon sistem memiliki *damping ratio* optimal tanpa *overshoot* ($M_p = 0\%$), menjaga suhu turun secara stabil dan mulus.
- Waktu transisi (*settling time*) tercapai pada $t_s \approx 4\tau \approx 160\text{ detik}$, di mana suhu stabil pada $24.0^\circ\text{C}$ dengan *steady-state error* $e_{ss} = 0.0^\circ\text{C}$.
- Motor blower AC beradaptasi secara bertingkat: 1.500 RPM saat awal pendinginan, 1.200 RPM saat pertengahan, 750 RPM saat mendekati target, dan 0 RPM saat target tercapai demi penghematan listrik optimal.

### 3.2 Sinkronisasi Slider & Input Angka pada Web Dashboard
Antarmuka web menggunakan JavaScript event listener:
- Saat slider digeser (`input` event): Nilai kotak angka langsung diperbarui dan dikirimkan ke ESP32 menggunakan REST API: `/set?target=XX`.
- Saat angka diketik (`change` event): Posisi slider langsung digeser ke angka tersebut dan dikirimkan ke ESP32.
- Data pemantauan suhu dan status diperbarui secara asinkron (AJAX fetch) setiap 1.5 detik melalui endpoint `/data` tanpa me-refresh halaman.

---

## BAB IV: PENGUJIAN DAN HASIL

### 4.1 Skenario Pengujian

| No | Suhu Ruangan ($T_{\text{aktual}}$) | Target Suhu ($T_{\text{target}}$) | Selisih ($\Delta T$) | Status AC yang Diharapkan | Hasil Pengujian |
|---|---|---|---|---|---|
| 1 | 29.5°C | 24.0°C | +5.5°C | DINGIN TINGGI (HIGH), LED Biru ON | **Berhasil** |
| 2 | 25.5°C | 24.0°C | +1.5°C | DINGIN NORMAL (MED), LED Biru ON | **Berhasil** |
| 3 | 23.8°C | 24.0°C | -0.2°C | STANDBY / HEMAT, LED Hijau ON | **Berhasil** |
| 4 | 22.0°C (via Slider) | Diubah ke 28.0°C (via Input Angka) | -6.0°C | Respon seketika: AC beralih ke STANDBY | **Berhasil** |

---

### 4.2 Skenario Pengujian Beban Termal Okupansi (Ruang Rapat & Kelas Telkom)
Sistem diuji dalam skenario ruang rapat interaktif dengan beban panas dinamis dari peserta rapat (metabolic body heat dissipation $\approx 100\text{ Watt}$ per orang):

| Skenario Rapat | Jumlah Peserta | Beban Termal Tubuh | Respon Alami Suhu Ruang | Tindakan Otomatis Sistem (Tanpa Input Manual) | Status Motor Blower & Kompresor |
|---|---|---|---|---|---|
| **Ruang Kosong** | 0 Orang | 0 Watt | Suhu stabil di 23.8°C - 24.0°C | Sistem mendeteksi suhu sudah tercapai | **STANDBY (0 RPM, Relay OFF)** |
| **Rapat Tim Kecil** | 3 - 4 Orang | ~300 - 400 Watt | Suhu perlahan naik ke 25.2°C | Sistem mendeteksi $\Delta T \approx 1.2^\circ\text{C}$ | **MED COOL (750 - 900 RPM, Relay ON)** |
| **Rapat Koordinasi** | 6 - 7 Orang | ~600 - 700 Watt | Suhu naik ke 26.5°C | Sistem mendeteksi $\Delta T \approx 2.5^\circ\text{C}$ | **HIGH COOL (1,200 RPM, PWM 205)** |
| **Rapat Pleno Buk Decy** | 10 Orang (Penuh) | 1,000 Watt! | Suhu melonjak ke 28.5°C - 29.5°C | Sistem mendeteksi $\Delta T \ge 4.0^\circ\text{C}$ | **TURBO COOL (1,500 RPM, PWM 255)** |

> **Catatan Pengujian:** Pada pengujian ini, pengguna tidak perlu menggeser slider suhu secara manual. Kenaikan suhu terjadi secara alami akibat disipasi panas tubuh para peserta rapat, dan mikrokontroler Arduino Uno secara mandiri (*autonomous closed-loop control*) mengerahkan daya pendinginan yang tepat untuk mempertahankan kenyamanan termal.

---

## BAB V: KESIMPULAN

1. Prototipe sistem pengatur suhu ruangan berbasis Arduino Uno / ESP32 dan sensor DHT22 berhasil dirancang dan disimulasikan secara mandiri tanpa memerlukan ketergantungan IoT.
2. Sistem kendali cerdas terbukti mampu mengimbangi beban termal okupansi manusia (hingga 10 peserta rapat / 1,000 Watt) secara otonom (*autonomous closed-loop*), menaikkan putaran blower hingga 1,500 RPM (TURBO) dan mengembalikan suhu ke target 24.0°C.
3. Visualisasi 3D realistis berbasis Three.js menampilkan suasana ruang rapat eksekutif lengkap dengan meja rapat, 10 peserta rapat beranimasi, layar smartboard presentasi interaktif, aliran hembusan angin realistis, dan grafik telemetri waktu-nyata bergaya MATLAB.
4. Fitur simulasi telah divalidasi dengan persamaan diferensial termal orde satu, menghasilkan respon transien yang stabil tanpa overshoot ($M_p = 0\%$) dan error steady state nol ($e_{ss} = 0^\circ\text{C}$).

---

*Lampiran Kode Program dan File Rangkaian dapat dilihat pada repositori tugas.*

