# PANDUAN PRESENTASI & TANYA JAWAB (Q&A) TUGAS BUK DECY
## Sistem Pengatur Suhu Ruangan Otomatis Berbasis ESP32 & DHT22

Dokumen ini berisi panduan cara menjelaskan proyek dan bocoran jawaban atas pertanyaan yang sering diajukan oleh dosen/guru saat ujian atau demonstrasi tugas.

---

## 🎤 1. Naskah Singkat Presentasi (Durasi 2 - 3 Menit)

> *"Selamat pagi/siang Buk Decy dan teman-teman semua.*  
> *Pada kesempatan kali ini, saya ingin mempresentasikan tugas sistem otomasi pengatur suhu ruangan cerdas mandiri (**Sistem Tertanam Non-IoT**) berbasis mikrokontroler **Arduino Uno R3** dan sensor digital **DHT22**.*
>
> *Sistem ini bekerja secara mandiri dan otonom 100% tanpa bergantung pada koneksi internet maupun WiFi, dengan alur kerja:*
> 1. *Sensor **DHT22** membaca suhu dan kelembapan ruangan secara real-time.*
> 2. *Pengguna mengatur target suhu kenyamanan ruangan secara fisik dengan memutar **Potensiometer** (16°C – 30°C) yang langsung terbaca di layar **LCD 16x2 I2C**.*
> 3. *Mikrokontroler Arduino Uno menghitung selisih suhu (&Delta;T) dan secara otomatis mengendalikan aktuator AC:*
>    - *Aktuator 1: **Relay 5V** untuk menghidupkan kompresor pendingin saat suhu panas.*
>    - *Aktuator 2: **Motor DC Blower AC** di mana **kecepatan putarannya (RPM)** ditentukan secara otomatis dan presisi berdasarkan selisih suhu: 1.500 RPM (Turbo Cool), 1.200 RPM (High Cool), 750 RPM (Med Cool), dan 0 RPM (Standby saat suhu tercapai).*
>    - *Disertai **Piezo Buzzer** sebagai respon suara setiap kali suhu diubah.*"

---

## ❓ 2. Bocoran Pertanyaan Dosen (Buk Decy) & Jawaban Tepatnya

### Pertanyaan 1: *"Kenapa memilih sensor DHT22, bukan DHT11?"*
**Jawaban Kamu:**
> *"Karena sensor DHT22 memiliki tingkat akurasi dan rentang ukur yang jauh lebih baik daripada DHT11, Bu.*  
> *Akurasi suhu DHT22 mencapai **±0.5°C** (sedangkan DHT11 hanya ±2°C), dan resolusi angkanya memiliki desimal (0.1°C), sehingga penyesuaian suhu AC menjadi jauh lebih halus dan presisi."*

---

### Pertanyaan 2: *"Bagaimana cara kerja slider dan kotak input angka di website agar bisa saling sinkron?"*
**Jawaban Kamu:**
> *"Di bagian frontend JavaScript, kami memasang **Event Listener**:*
> - *Pada Slider digunakan event `input`, sehingga saat slider digeser seketika nilai kotak angka diperbarui dan dikirimkan ke ESP32.*
> - *Pada Input Angka digunakan event `change`, sehingga ketika pengguna mengetik angka baru, slider langsung bergeser otomatis ke posisi angka tersebut.*
> - *Selain itu, kami menambahkan fungsi **debounce** sekitar 300 milidetik agar saat slider digeser dengan cepat, ESP32 tidak menerima terlalu banyak request bertubi-tubi (mencegah lag)."*

---

### Pertanyaan 3: *"Apakah Web Server di ESP32 ini butuh kuota internet luar?"*
**Jawaban Kamu:**
> *"Tidak butuh kuota internet luar sama sekali, Bu.*  
> *ESP32 bertindak sebagai **Local Web Server** mandiri (Port 80) menggunakan library `WebServer.h`. Seluruh kode tampilan HTML, CSS, dan JavaScript disimpan langsung di memori Flash ESP32 (menggunakan `PROGMEM`). Jadi smartphone atau laptop tinggal terhubung ke WiFi Access Point ESP32 dan langsung bisa membuka dashboard."*

---

### Pertanyaan 4: *"Bagaimana logika otomatisasi AC memutuskan kapan harus kencang dan kapan harus mati/standby?"*
**Jawaban Kamu:**
> *"Logikanya didasarkan pada selisih suhu ($\Delta T = T_{\text{aktual}} - T_{\text{target}}$):*
> 1. *Jika $\Delta T \ge 2^\circ\text{C}$ (ruangan masih jauh lebih panas), AC bekerja pada level **HIGH** (Kompresor aktif penuh, semburan udara kencang).*
> 2. *Jika $0^\circ\text{C} < \Delta T < 2^\circ\text{C}$ (suhu mulai mendekati target), AC beralih ke level **MEDIUM** (Pendinginan normal).*
> 3. *Jika $\Delta T \le 0^\circ\text{C}$ (suhu target sudah tercapai), AC masuk ke mode **STANDBY** (Kompresor mati, LED hijau standby menyala, semburan udara berhenti untuk hemat listrik)."*

---

### Pertanyaan 5: *"Apa fungsi modul I2C pada layar LCD 16x2?"*
**Jawaban Kamu:**
> *"Fungsi modul I2C adalah untuk **menghemat pin GPIO** pada ESP32, Bu.*  
> *Layar LCD 16x2 paralel biasa membutuhkan hingga 16 pin kabel. Dengan modul konverter I2C, kita hanya butuh 2 pin komunikasi data saja, yaitu **SDA (GPIO 21)** dan **SCL (GPIO 22)** pada ESP32."*

---

### Pertanyaan 6: *"Bagaimana kalau di dunia nyata kita ingin mengontrol AC fisik sungguhan?"*
**Jawaban Kamu:**
> *"Untuk AC fisik sungguhan, ada dua metode umum:*
> 1. *Menggunakan **Modul Relay** untuk memutus dan menyambungkan daya kompresor AC (untuk AC sederhana/kipas).*
> 2. *Menggunakan **Transmitter IR (Inframerah)** dengan library `IRremoteESP8266` untuk meniru sinyal remote AC asli, sehingga ESP32 bisa mengubah suhu, mode, dan fan speed AC bawaan pabrik secara nirkabel."*

---

### Pertanyaan 7: *"Kenapa menggunakan Motor DC dan bagaimana cara menentukan kecepatan RPM-nya?"*
**Jawaban Kamu:**
> *"Motor DC pada sistem ini berfungsi sebagai **Blower Kipas Evaporator AC**, Bu. Kecepatan putarannya (RPM) ditentukan secara proporsional menggunakan sinyal **PWM (Pulse Width Modulation)** di Pin 6 Arduino berdasarkan selisih suhu aktual terhadap suhu target (&Delta;T):*
> 1. ***&Delta;T &ge; 4.0°C (Sangat Panas)**: Kecepatan disetel ke **1.500 RPM** (PWM 255 / 100%) untuk mendinginkan ruangan secepat mungkin (Mode Turbo).*
> 2. ***2.0°C &le; &Delta;T < 4.0°C (Panas)**: Kecepatan diturunkan ke **1.200 RPM** (PWM 205 / ~80%) untuk pendinginan cepat yang stabil (Mode High).*
> 3. ***0.0°C < &Delta;T < 2.0°C (Mendekati Target)**: Kecepatan diturunkan ke **750 RPM** (PWM 135 / ~53%) agar hembusan angin sejuk dan tidak berisik (Mode Med).*
> 4. ***&Delta;T &le; 0.0°C (Target Tercapai)**: Motor berhenti ke **0 RPM** (PWM 0) dan kompresor mati untuk menghemat daya listrik (Mode Standby).*
> *Nilai RPM ini dihitung oleh mikrokontroler dan ditampilkan secara realtime di baris kedua LCD 16x2."*

---

### Pertanyaan 8: *"Bagaimana cara mengubah target suhu jika menggunakan Arduino Uno tanpa koneksi WiFi?"*
**Jawaban Kamu:**
> *"Pada Arduino Uno, kami menyediakan 2 mekanisme:*
> 1. ***Slider Fisik Menggunakan Potensiometer di Pin A0**: Nilai analog 0-1023 dipetakan (*mapping*) menjadi skala suhu 16.0°C hingga 30.0°C dengan step 0.5°C.*
> 2. ***Input Serial Monitor**: Pengguna bisa mengetikkan angka suhu langsung dari laptop melalui Serial Monitor (contoh: ketik `23.5`), sehingga pengujian di kelas menjadi sangat cepat dan praktis."*

---

### Pertanyaan 9: *"Bagaimana cara kerja fitur klik langsung pada komponen 3D (seperti sensor DHT22 dan AC) di browser?"*
**Jawaban Kamu:**
> *"Fitur ini menggunakan teknik **Raycasting** pada library Three.js, Bu.*  
> *Ketika pengguna mengklik layar, sistem menembakkan garis maya (ray) dari posisi kamera 2D menembus ruang 3D. Jika garis tersebut bertabrakan (intersect) dengan objek seperti sensor DHT22 atau unit AC, koordinat tabrakan tersebut ditangkap untuk memunculkan antarmuka pengaturan suhu tepat pada objek tersebut."*

---

### Pertanyaan 10: *"Platform simulasi apa saja yang didukung oleh proyek ini jika ingin diuji coba?"*
**Jawaban Kamu:**
> *"Proyek ini dirancang sangat fleksibel dan mendukung **4 platform simulasi sekaligus**, Bu:*
> 1. ***Autodesk Tinkercad Circuits**: Menggunakan mikrokontroler Arduino Uno, sensor suhu TMP36, Motor DC Blower AC dengan display RPM, Relay Kompresor, dan Potensiometer target suhu (File: `sketch_tinkercad.ino`).*
> 2. ***Wokwi Simulator**: Mendukung simulasi sensor DHT22, LCD I2C, dan mikrokontroler Arduino Uno maupun ESP32 secara akurat (File: `diagram_uno.json` dan `diagram.json`).*
> 3. ***Visual Digital Twin 3D WebGL (Three.js)**: Simulasi 3D interaktif fotorealistik langsung di browser laptop dengan hembusan angin dinamis yang kecepatannya mengikuti suhu aktual (File: `simulasi_3d.html`).*
> 4. ***Web Server IoT Lokal (ESP32 Fisik)**: ESP32 memancarkan WiFi mandiri dan menyajikan dashboard kontrol suhu berslider ke HP/Laptop tanpa perlu kuota internet luar.*"

