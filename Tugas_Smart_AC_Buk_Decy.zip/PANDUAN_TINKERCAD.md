# PANDUAN LENGKAP SIMULASI DI AUTODESK TINKERCAD CIRCUITS
## Proyek Smart AC Otomatis (Arduino Uno + TMP36 + Motor DC Pengatur RPM)

**Penyusun:** Ardi Hidayat (XI TELK 4)  
**Guru Pengampu:** Buk Decy  
**Sistem:** Standalone Embedded System (Non-IoT)

Apakah simulasi ini bisa dijalankan di **Autodesk Tinkercad**?  
**JAWABANNYA: BISA BANGET! (100% DIDUKUNG)** 🚀

Di Tinkercad Circuits, ada komponen bawaan **DC Motor** yang **secara visual berputar dan menampilkan kecepatan RPM secara langsung** saat simulasi berjalan. Hal ini sangat sempurna untuk mendemonstrasikan pengaturan RPM motor blower AC berdasarkan suhu ruangan kepada Buk Decy.

---

## 🛠️ Komponen yang Ditarik di Tinkercad:
Buka [https://www.tinkercad.com/circuits](https://www.tinkercad.com/circuits), buat sirkuit baru (*Create New Circuit*), lalu tarik komponen berikut dari panel sebelah kanan:

1. **Arduino Uno R3** (1 buah)
2. **Breadboard Kecil / Small Breadboard** (1 buah)
3. **Sensor Suhu [TMP36]** (1 buah)  
   *(Catatan: Di Tinkercad, sensor suhu standarnya adalah TMP36. Saat simulasi berjalan, cukup klik sensornya untuk menggeser suhu ruangan).*
4. **Potensiometer 10kΩ** (1 buah) $\rightarrow$ Slider fisik pengatur target suhu (16°C – 30°C).
5. **Motor DC / DC Motor** (1 buah) $\rightarrow$ Aktuator motor kipas/blower AC dengan pembacaan RPM otomatis!
6. **Relay SPDT** (1 buah) $\rightarrow$ Aktuator saklar kompresor AC.
7. **Piezo Buzzer** (1 buah) $\rightarrow$ Respon bunyi Beep saat target disetel.
8. **Layar LCD 16x2 (I2C)** (1 buah) $\rightarrow$ Menampilkan Suhu, RPM Motor, dan Mode AC.

---

## 🔌 Skema Perkabelan (Wiring) di Tinkercad:

### Diagram Sambungan Pin Arduino Uno:
```
           +------------------------------------------+
           |             ARDUINO UNO R3               |
           |                                          |
           |   [A0] <--- Kaki Tengah Potensiometer     |
           |   [A1] <--- Kaki Tengah Sensor TMP36      |
           |   [A4] <--- Pin SDA Layar LCD 16x2 I2C   |
           |   [A5] <--- Pin SCL Layar LCD 16x2 I2C   |
           |                                          |
           |   [D6] ---> Terminal Positif Motor DC    |
           |   [D7] ---> Terminal Coil 1 Relay SPDT   |
           |   [D8] ---> Kaki Positif Piezo Buzzer    |
           |                                          |
           |   [5V] ---> Jalur Merah (+) Breadboard   |
           |  [GND] ---> Jalur Hitam (-) Breadboard   |
           +------------------------------------------+
```

### Rincian Sambungan Tiap Komponen:

#### 1. Jalur Catu Daya (Power Rails)
- Sambungkan pin **5V** Arduino ke jalur merah (`+`) Breadboard.
- Sambungkan pin **GND** Arduino ke jalur hitam (`-`) Breadboard.

#### 2. Sensor Suhu TMP36 (3 Kaki)
*(Hadapkan sensor dengan sisi lengkung menghadap ke depan)*
- **Kaki Kiri (Power)** $\rightarrow$ Jalur `+` 5V Breadboard (Kabel Merah)
- **Kaki Tengah (Vout)** $\rightarrow$ Pin Analog **A1** Arduino (Kabel Hijau)
- **Kaki Kanan (GND)** $\rightarrow$ Jalur `-` GND Breadboard (Kabel Hitam)

#### 3. Potensiometer (Pengatur Target Suhu)
- **Kaki Kiri (Terminal 1)** $\rightarrow$ Jalur `+` 5V (Kabel Merah)
- **Kaki Tengah (Wiper)** $\rightarrow$ Pin Analog **A0** Arduino (Kabel Oranye)
- **Kaki Kanan (Terminal 2)** $\rightarrow$ Jalur `-` GND (Kabel Hitam)

#### 4. Motor DC (Aktuator Blower AC dengan Kontrol RPM)
- **Terminal 1 (Positif)** $\rightarrow$ Pin Digital **~6** (PWM) Arduino (Kabel Cyan / Biru)
- **Terminal 2 (Negatif)** $\rightarrow$ Jalur `-` GND Breadboard (Kabel Hitam)

#### 5. Relay SPDT (Saklar Kompresor AC)
- **Terminal Coil 1** $\rightarrow$ Pin Digital **7** Arduino (Kabel Ungu)
- **Terminal Coil 2** $\rightarrow$ Jalur `-` GND Breadboard (Kabel Hitam)

#### 6. Piezo Buzzer (Indikator Beep)
- **Kaki Positif (+)** $\rightarrow$ Pin Digital **8** Arduino (Kabel Kuning)
- **Kaki Negatif (-)** $\rightarrow$ Jalur `-` GND Breadboard (Kabel Hitam)

#### 7. Layar LCD 16x2 I2C (4 Pin)
- **GND** $\rightarrow$ Jalur `-` GND
- **VCC** $\rightarrow$ Jalur `+` 5V
- **SDA** $\rightarrow$ Pin Analog **A4** Arduino (Kabel Biru)
- **SCL** $\rightarrow$ Pin Analog **A5** Arduino (Kabel Kuning)

---

## 💻 Cara Memasukkan Kode ke Tinkercad:

1. Di halaman Tinkercad Circuits, klik tombol **Code** di pojok kanan atas.
2. Ubah mode dropdown dari **Blocks** menjadi **Text**. Jika ada konfirmasi konversi, klik **Continue**.
3. Hapus semua kode bawaan yang ada di kotak teks tersebut.
4. Buka file **[`sketch_tinkercad.ino`](file:///d:/tugas%20buk%20decy/sketch_tinkercad.ino)** di folder tugas kamu, salin (*Ctrl+A* lalu *Ctrl+C*), dan tempel (*Ctrl+V*) ke editor Tinkercad.
5. Klik **Start Simulation** (Mulai Simulasi).

---

## 🎮 Cara Menguji Penentuan RPM Motor di Tinkercad:

1. **Uji Kondisi TURBO (1.500 RPM):**
   - Geser Potensiometer ke target rendah (misal: 20°C).
   - Klik sensor **TMP36**, geser slider suhu ke **26°C** atau lebih panas ($\Delta T \ge 4^\circ\text{C}$).
   - **Hasil:** Motor DC berputar kencang, Tinkercad menampilkan angka putaran tinggi (~1.500 RPM), relay kompresor aktif, dan LCD menampilkan `1500RPM [TURBO]`.

2. **Uji Kondisi HIGH (1.200 RPM):**
   - Geser suhu TMP36 ke **23°C** dengan target 20°C ($\Delta T = 3^\circ\text{C}$).
   - **Hasil:** Putaran motor melambat ke ~1.200 RPM, LCD menampilkan `1200RPM [HIGH]`.

3. **Uji Kondisi MED (750 RPM):**
   - Geser suhu TMP36 ke **21°C** dengan target 20°C ($\Delta T = 1^\circ\text{C}$).
   - **Hasil:** Putaran motor berputar sedang (~750 RPM), LCD menampilkan `750RPM [MED]`.

4. **Uji Kondisi STANDBY / IDLE (0 RPM):**
   - Geser suhu TMP36 sama dengan atau lebih dingin dari target (misal: 19°C).
   - **Hasil:** Motor DC berhenti berputar (0 RPM), relay kompresor mati, LCD menampilkan `0RPM [IDLE]`.
