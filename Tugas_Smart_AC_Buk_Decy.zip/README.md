# Simulasi Smart AC ESP32 & DHT22 dengan Web Dashboard

Proyek simulasi sistem pengatur suhu ruangan otomatis berbasis **ESP32** dan sensor **DHT22**. Proyek ini memungkinkan pengguna mengatur target suhu ruangan melalui Web Dashboard interaktif (slider dan input angka) secara real-time via koneksi WiFi.

---

## 🌟 Fitur Utama
1. **Simulasi 3D Interaktif Cyberpunk Edition (`simulasi_3d.html`)**:
   - **Komponen 3D Bisa Diklik Langsung (*Interactive Raycasting*)**:
     - **Klik Sensor DHT22**: Memunculkan tombol stepper `[ − ]` dan `[ + ]` serta tombol 🔥 Panas / 🧊 Dingin tepat di atas sensor untuk mengubah suhu lingkungan secara real-time.
     - **Klik Unit AC**: Mengubah target suhu AC secara berurutan (18°C $\rightarrow$ 22°C $\rightarrow$ 24°C $\rightarrow$ 26°C).
     - **Klik Lampu Tidur**: Menyalakan dan mematikan lampu meja samping ranjang.
   - **Tampilan Ruangan Bersih & Elegan**: Kotak statis yang menghalangi pandangan telah dihilangkan sehingga tampilan 3D bebas dinikmati.
   - **3 Pilihan Tema Lampu LED Kamar**: Cyberpunk (*Magenta + Cyan*), Ice Blue (*Biru Es Dingin*), dan Warm Amber (*Emas Hangat*).
   - **Efek Hembusan Angin Realistis**: Kerucut cahaya biru bersinar (*radiant volumetric cone*), sayap louver berayun dinamis, dan ratusan partikel kabut es melayang melintasi kamar.
2. **Kontrol Target Suhu Fleksibel**:
   - Menggunakan **Slider** interaktif dan **Input Angka** yang saling tersinkronisasi di sidebar kanan.
4. **Logika Kontrol AC Otomatis**:
   - Jika Suhu Ruangan > Target Suhu + 1.5°C: **AC Level TINGGI (High Cooling)** - Hembusan udara maksimal.
   - Jika Suhu Ruangan > Target Suhu: **AC Level SEDANG (Normal Cooling)** - Hembusan udara normal.
   - Jika Suhu Ruangan <= Target Suhu: **AC Standby / Hemat Energi** - Sayap menutup, hembusan berhenti.
5. **Indikator Visual & Layar**:
   - Layar **LCD 16x2 (I2C)** virtual & fisik menampilkan Suhu Aktual, Target Suhu, dan Status AC.
   - **LED / Relay** sebagai indikator kompresor AC aktif.

---

## 🛠️ Komponen yang Digunakan
1. **ESP32 Dev Module**
2. **Sensor Suhu & Kelembapan DHT22**
3. **LCD Display 16x2 I2C** (Alamat: `0x27`)
4. **LED Biru (Simulasi Kompresor AC)** + Resistor 220Ω
5. **LED Hijau (Indikator Power/Standby)** + Resistor 220Ω

---

## 🔌 Rangkaian Pin (Wiring)
| Komponen | Pin Komponen | Pin ESP32 |
|---|---|---|
| **DHT22** | VCC | 3.3V / 5V |
| | GND | GND |
| | DATA | GPIO 15 |
| **LCD 16x2 I2C** | VCC | 5V (VIN) |
| | GND | GND |
| | SDA | GPIO 21 |
| | SCL | GPIO 22 |
| **LED Biru (AC Aktif)** | Anoda (+) | GPIO 2 |
| | Katoda (-) | GND (lewat Resistor 220Ω) |
| **LED Hijau (Standby)** | Anoda (+) | GPIO 4 |
| | Katoda (-) | GND (lewat Resistor 220Ω) |

---

## 🚀 Cara Menjalankan Simulasi di Wokwi
1. Buka browser dan kunjungi [https://wokwi.com](https://wokwi.com).
2. Pilih **ESP32** -> **Arduino ESP32**.
3. Salin isi file `sketch.ino` ke tab kode Wokwi.
4. Buka tab **diagram.json** di Wokwi, ganti isinya dengan file `diagram.json` yang ada di repositori ini.
5. Di tab **Library Manager** (ikon buku di Wokwi), pastikan library berikut terpasang:
   - `DHT sensor library` (oleh Adafruit)
   - `LiquidCrystal I2C`
6. Klik tombol **Start Simulation** (Play).
7. Klik sensor DHT22 di layar simulasi untuk mengubah suhu/kelembapan secara manual guna melihat respon AC otomatis!

