@echo off
title Membuka Portal Tugas Buk Decy
echo ====================================================
echo   MEMBUKA PORTAL TUGAS SISTEM SMART AC (BUK DECY)
echo   STANDALONE EMBEDDED SYSTEM - XI TELK 4 ARDI
echo ====================================================
start "" "%~dp0index.html"
exit
