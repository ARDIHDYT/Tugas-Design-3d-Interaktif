import matplotlib.pyplot as plt
import numpy as np

# Set MATLAB-like styling
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['figure.dpi'] = 300

# -------------------------------------------------------------
# GRAFIK 1: SIMULASI RESPON DINAMIS WAKTU (MATLAB SIMULINK STYLE)
# -------------------------------------------------------------
time = np.linspace(0, 180, 500) # 0 to 180 seconds

# Initial room temperature = 32°C, Target setpoint = 24°C
# Temperature decay model: T(t) = T_target + (T_init - T_target) * exp(-t / tau)
t_init = 32.0
t_target = 24.0
tau = 45.0 # thermal time constant in seconds
temp_actual = t_target + (t_init - t_target) * np.exp(-time / tau)

# Calculate Delta T
delta_t = temp_actual - t_target

# Calculate RPM and Compressor state based on logic
rpm = np.zeros_like(time)
compressor = np.zeros_like(time)
pwm = np.zeros_like(time)

for i in range(len(time)):
    dt = delta_t[i]
    if dt >= 4.0:
        rpm[i] = 1500
        pwm[i] = 255
        compressor[i] = 1
    elif dt >= 2.0:
        rpm[i] = 1200
        pwm[i] = 205
        compressor[i] = 1
    elif dt > 0.05:
        rpm[i] = 750
        pwm[i] = 135
        compressor[i] = 1
    else:
        rpm[i] = 0
        pwm[i] = 0
        compressor[i] = 0

# Create MATLAB-style Figure with 2 subplots
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 7), sharex=True, gridspec_kw={'height_ratios': [1.3, 1]})
fig.patch.set_facecolor('#ffffff')

# Subplot 1: Temperature Response
ax1.set_facecolor('#f8fafc')
ax1.plot(time, temp_actual, color='#0072BD', linewidth=2.5, label='Suhu Aktual Ruangan $T_{ruang}(t)$ (DHT22)')
ax1.axhline(y=t_target, color='#D95319', linestyle='--', linewidth=2.0, label='Target Setpoint $T_{set} = 24.0^\circ$C')
ax1.axhline(y=t_target + 4.0, color='#EDB120', linestyle=':', linewidth=1.2, alpha=0.7, label='Batas Turbo ($\Delta T \geq 4^\circ$C)')
ax1.axhline(y=t_target + 2.0, color='#7E2F8E', linestyle=':', linewidth=1.2, alpha=0.7, label='Batas High ($\Delta T \geq 2^\circ$C)')

# Annotations
ax1.annotate('Zona TURBO (1500 RPM)', xy=(15, 29), xytext=(25, 30.5),
             arrowprops=dict(facecolor='#0072BD', shrink=0.08, width=1.5, headwidth=6),
             fontsize=9, fontweight='bold', color='#0072BD')
ax1.annotate('Zona HIGH (1200 RPM)', xy=(55, 26.5), xytext=(70, 28),
             arrowprops=dict(facecolor='#7E2F8E', shrink=0.08, width=1.5, headwidth=6),
             fontsize=9, fontweight='bold', color='#7E2F8E')
ax1.annotate('Zona MED (750 RPM)', xy=(110, 24.6), xytext=(120, 26),
             arrowprops=dict(facecolor='#EDB120', shrink=0.08, width=1.5, headwidth=6),
             fontsize=9, fontweight='bold', color='#B8860B')
ax1.annotate('Target Tercapai: IDLE / STANDBY (0 RPM)\nKompresor OFF (Hemat Energi)', xy=(165, 24.05), xytext=(115, 22.8),
             arrowprops=dict(facecolor='#77AC30', shrink=0.08, width=1.5, headwidth=6),
             fontsize=9, fontweight='bold', color='#2E7D32', bbox=dict(boxstyle='round,pad=0.3', facecolor='#E8F5E9', edgecolor='#4CAF50'))

ax1.set_ylabel('Suhu Ruangan ($^\circ$C)', fontsize=11, fontweight='bold')
ax1.set_title('MATLAB R2024b - Respon Transien Suhu Ruang & Aktuator Smart AC (Non-IoT)', fontsize=13, fontweight='bold', pad=12)
ax1.grid(True, linestyle='--', alpha=0.6, color='#cbd5e1')
ax1.legend(loc='upper right', framealpha=0.95, fontsize=9)
ax1.set_ylim(22.5, 33.5)

# Subplot 2: Actuator RPM Response
ax2.set_facecolor('#f8fafc')
ax2.step(time, rpm, color='#D95319', linewidth=2.2, where='post', label='Kecepatan Motor Blower AC (RPM)')
ax2.set_ylabel('Putaran Motor (RPM)', fontsize=11, fontweight='bold', color='#D95319')
ax2.tick_params(axis='y', labelcolor='#D95319')
ax2.grid(True, linestyle='--', alpha=0.6, color='#cbd5e1')
ax2.set_ylim(-100, 1700)

# Secondary Y-Axis for Compressor State
ax2_twin = ax2.twinx()
ax2_twin.step(time, compressor, color='#77AC30', linewidth=1.8, linestyle='-.', where='post', label='Relay Kompresor (1=ON, 0=OFF)')
ax2_twin.set_ylabel('Status Relay Kompresor', fontsize=11, fontweight='bold', color='#2E7D32')
ax2_twin.tick_params(axis='y', labelcolor='#2E7D32')
ax2_twin.set_ylim(-0.2, 1.4)
ax2_twin.set_yticks([0, 1])
ax2_twin.set_yticklabels(['OFF (Idle)', 'ON (Cooling)'])

# Combined Legend for Subplot 2
lines_1, labels_1 = ax2.get_legend_handles_labels()
lines_2, labels_2 = ax2_twin.get_legend_handles_labels()
ax2.legend(lines_1 + lines_2, labels_1 + labels_2, loc='upper right', framealpha=0.95, fontsize=9)

ax2.set_xlabel('Waktu Simulasi $t$ (Detik)', fontsize=11, fontweight='bold')

plt.tight_layout()
plt.savefig('grafik_respon_matlab.png', dpi=300)
plt.close()
print("Berhasil membuat grafik_respon_matlab.png")

# -------------------------------------------------------------
# GRAFIK 2: FUNGSI TRANSFER KARAKTERISTIK KENDALI (RPM VS DELTA T)
# -------------------------------------------------------------
delta_vals = np.linspace(-2.0, 7.0, 400)
rpm_vals = np.zeros_like(delta_vals)
pwm_vals = np.zeros_like(delta_vals)

for i, dt in enumerate(delta_vals):
    if dt >= 4.0:
        rpm_vals[i] = 1500
        pwm_vals[i] = 255
    elif dt >= 2.0:
        rpm_vals[i] = 1200
        pwm_vals[i] = 205
    elif dt > 0.0:
        rpm_vals[i] = 750
        pwm_vals[i] = 135
    else:
        rpm_vals[i] = 0
        pwm_vals[i] = 0

fig2, ax = plt.subplots(figsize=(9, 5.2))
fig2.patch.set_facecolor('#ffffff')
ax.set_facecolor('#f8fafc')

# Plot step transfer function
ax.step(delta_vals, rpm_vals, color='#0072BD', linewidth=2.8, where='post', label='Karakteristik Kecepatan Blower $RPM(\Delta T)$')

# Fill zones
ax.axvspan(-2.0, 0.0, color='#E8F5E9', alpha=0.7, label='Zona 1: Standby ($\Delta T \leq 0^\circ$C) $\\rightarrow$ 0 RPM')
ax.axvspan(0.0, 2.0, color='#FFFDE7', alpha=0.7, label='Zona 2: Med Cool ($0^\circ\\text{C} < \Delta T < 2^\circ$C) $\\rightarrow$ 750 RPM')
ax.axvspan(2.0, 4.0, color='#E1F5FE', alpha=0.7, label='Zona 3: High Cool ($2^\circ\\text{C} \leq \Delta T < 4^\circ$C) $\\rightarrow$ 1200 RPM')
ax.axvspan(4.0, 7.0, color='#FFEBEE', alpha=0.7, label='Zona 4: Turbo Cool ($\Delta T \geq 4^\circ$C) $\\rightarrow$ 1500 RPM')

ax.set_title('MATLAB R2024b - Karakteristik Kendali Otomatis: Putaran Motor AC (RPM) vs Selisih Suhu ($\Delta T$)', fontsize=11, fontweight='bold', pad=12)
ax.set_xlabel('Selisih Suhu Ruangan $\Delta T = T_{aktual} - T_{target}$ ($^\circ$C)', fontsize=10, fontweight='bold')
ax.set_ylabel('Kecepatan Putaran Motor Blower (RPM)', fontsize=10, fontweight='bold', color='#0072BD')
ax.grid(True, linestyle='--', alpha=0.6, color='#cbd5e1')
ax.set_ylim(-100, 1750)
ax.set_xlim(-2.0, 7.0)

# Secondary axis for PWM
ax_pwm = ax.twinx()
ax_pwm.set_ylabel('Nilai Sinyal PWM (0 - 255)', fontsize=10, fontweight='bold', color='#D95319')
ax_pwm.tick_params(axis='y', labelcolor='#D95319')
ax_pwm.set_ylim(-100 * (255/1500), 1750 * (255/1500))
ax_pwm.set_yticks([0, 135, 205, 255])
ax_pwm.set_yticklabels(['0 (0%)', '135 (53%)', '205 (80%)', '255 (100%)'])

ax.legend(loc='upper left', framealpha=0.95, fontsize=8.5)

plt.tight_layout()
plt.savefig('grafik_karakteristik_rpm.png', dpi=300)
plt.close()
print("Berhasil membuat grafik_karakteristik_rpm.png")

