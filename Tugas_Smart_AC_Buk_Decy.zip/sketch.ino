/*
  =============================================================================
  PROYEK SIMULASI SMART AC BERBASIS ESP32 & DHT22 DENGAN WEB DASHBOARD
  -----------------------------------------------------------------------------
  Deskripsi:
  Sistem pengatur suhu ruangan otomatis dengan sensor DHT22.
  Target suhu dapat diatur secara real-time melalui Web Dashboard
  menggunakan Slider atau Input Angka (keduanya tersinkronisasi).
  ESP32 akan menyesuaikan daya/kecepatan AC secara otomatis berdasarkan
  selisih antara suhu aktual dan target suhu yang ditentukan.
  =============================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// ==================== KONFIGURASI PIN & HARDWARE ====================
#define DHTPIN 15
#define DHTTYPE DHT22

#define PIN_LED_AC 2       // Indikator Kompresor AC Aktif (LED Biru)
#define PIN_LED_STANDBY 4  // Indikator Suhu Tercapai / Standby (LED Hijau)

// Inisialisasi Sensor & LCD (Alamat I2C umum: 0x27)
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Inisialisasi Web Server di Port 80
WebServer server(80);

// ==================== KONFIGURASI JARINGAN (WIFI) ====================
// Mode 1: WiFi Access Point (ESP32 memancarkan WiFi sendiri)
const char* ap_ssid = "Smart-AC-ESP32";
const char* ap_pass = "12345678";

// Mode 2: Station (Koneksi ke WiFi Wokwi Simulator atau Router Rumah)
const char* sta_ssid = "Wokwi-GUEST";
const char* sta_pass = "";

// ==================== VARIABEL SISTEM ====================
float currentTemp = 28.0;       // Suhu saat ini (°C)
float currentHumidity = 60.0;   // Kelembapan saat ini (%)
float targetTemp = 24.0;        // Target suhu (default 24°C)
String acStatus = "STANDBY";    // Status AC
String acSpeed = "OFF";         // Kecepatan Fan/Kompresor AC
unsigned long lastSensorRead = 0;
const unsigned long SENSOR_INTERVAL = 2000; // Baca sensor tiap 2 detik

// ==================== HALAMAN WEB DASHBOARD (HTML+CSS+JS) ====================
const char PAGE_MAIN[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart AC Controller - ESP32</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    body {
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      color: #f8fafc;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    .container {
      width: 100%;
      max-width: 480px;
      background: rgba(30, 41, 59, 0.85);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 24px;
      padding: 28px;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
    }
    .header { text-align: center; margin-bottom: 24px; }
    .header h1 { font-size: 1.6rem; font-weight: 700; color: #38bdf8; display: flex; align-items: center; justify-content: center; gap: 8px; }
    .header p { font-size: 0.85rem; color: #94a3b8; margin-top: 4px; }
    
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 20px; }
    .card {
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 16px;
      padding: 16px;
      text-align: center;
    }
    .card-title { font-size: 0.8rem; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.5px; }
    .card-value { font-size: 2rem; font-weight: 700; margin-top: 6px; color: #f1f5f9; }
    .card-unit { font-size: 0.9rem; font-weight: 400; color: #38bdf8; }

    /* AC Status Banner */
    .status-card {
      background: rgba(15, 23, 42, 0.8);
      border: 1px solid rgba(56, 189, 248, 0.2);
      border-radius: 18px;
      padding: 18px;
      margin-bottom: 20px;
      text-align: center;
      transition: all 0.3s ease;
    }
    .badge {
      display: inline-block;
      padding: 6px 16px;
      border-radius: 9999px;
      font-size: 0.85rem;
      font-weight: 700;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
    }
    .badge-cool { background: rgba(14, 165, 233, 0.2); color: #38bdf8; border: 1px solid #0284c7; }
    .badge-standby { background: rgba(34, 197, 94, 0.2); color: #4ade80; border: 1px solid #16a34a; }
    .status-desc { font-size: 0.95rem; color: #cbd5e1; }

    /* Control Target Card */
    .control-card {
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 18px;
      padding: 20px;
      margin-bottom: 20px;
    }
    .control-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 14px;
    }
    .control-title { font-size: 0.9rem; font-weight: 600; color: #e2e8f0; }
    
    /* Input Angka */
    .number-input-wrap {
      display: flex;
      align-items: center;
      gap: 6px;
      background: #1e293b;
      padding: 4px 10px;
      border-radius: 10px;
      border: 1px solid #334155;
    }
    .number-input-wrap input {
      width: 55px;
      background: transparent;
      border: none;
      color: #38bdf8;
      font-size: 1.1rem;
      font-weight: bold;
      text-align: center;
      outline: none;
    }
    .number-input-wrap span { color: #94a3b8; font-size: 0.9rem; }

    /* Slider */
    .slider-wrap { margin: 18px 0; }
    input[type=range] {
      -webkit-appearance: none;
      width: 100%;
      height: 10px;
      border-radius: 5px;
      background: #334155;
      outline: none;
      transition: background 0.2s;
    }
    input[type=range]::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: #38bdf8;
      cursor: pointer;
      box-shadow: 0 0 12px rgba(56, 189, 248, 0.8);
      transition: transform 0.1s;
    }
    input[type=range]::-webkit-slider-thumb:hover { transform: scale(1.15); }
    .slider-labels {
      display: flex;
      justify-content: space-between;
      font-size: 0.75rem;
      color: #64748b;
      margin-top: 6px;
    }

    /* Preset Quick Buttons */
    .presets { display: flex; gap: 8px; justify-content: center; margin-top: 12px; }
    .btn-preset {
      flex: 1;
      background: #1e293b;
      border: 1px solid #334155;
      color: #cbd5e1;
      padding: 8px 4px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 0.8rem;
      font-weight: 500;
      transition: all 0.2s;
    }
    .btn-preset:hover { background: #38bdf8; color: #0f172a; border-color: #38bdf8; }

    .footer { text-align: center; font-size: 0.75rem; color: #64748b; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>❄️ Smart AC Controller</h1>
      <p>Simulasi ESP32 + DHT22 Suhu Ruangan</p>
    </div>

    <!-- Sensor Monitoring Grid -->
    <div class="grid">
      <div class="card">
        <div class="card-title">Suhu Ruangan</div>
        <div class="card-value" id="val-temp">--</div>
        <div class="card-unit">°C</div>
      </div>
      <div class="card">
        <div class="card-title">Kelembapan</div>
        <div class="card-value" id="val-hum">--</div>
        <div class="card-unit">% RH</div>
      </div>
    </div>

    <!-- AC Status Banner -->
    <div class="status-card" id="status-box">
      <span class="badge badge-cool" id="status-badge">MEMUAT...</span>
      <div class="status-desc" id="status-text">Menghubungkan ke sistem pendingin...</div>
    </div>

    <!-- Target Control -->
    <div class="control-card">
      <div class="control-header">
        <div class="control-title">🎯 Atur Target Suhu</div>
        <div class="number-input-wrap">
          <input type="number" id="input-number" min="16" max="30" step="0.5" value="24">
          <span>°C</span>
        </div>
      </div>

      <!-- Slider Target -->
      <div class="slider-wrap">
        <input type="range" id="input-slider" min="16" max="30" step="0.5" value="24">
        <div class="slider-labels">
          <span>16°C (Sangat Dingin)</span>
          <span>24°C (Normal)</span>
          <span>30°C (Hemat)</span>
        </div>
      </div>

      <!-- Tombol Cepat (Preset) -->
      <div class="presets">
        <button class="btn-preset" onclick="setPreset(18)">18°C Sejuk</button>
        <button class="btn-preset" onclick="setPreset(22)">22°C Standar</button>
        <button class="btn-preset" onclick="setPreset(25)">25°C Nyaman</button>
      </div>
    </div>

    <div class="footer">
      ESP32 Room Climate Automation System
    </div>
  </div>

  <script>
    const slider = document.getElementById('input-slider');
    const numberInput = document.getElementById('input-number');
    const valTemp = document.getElementById('val-temp');
    const valHum = document.getElementById('val-hum');
    const statusBadge = document.getElementById('status-badge');
    const statusText = document.getElementById('status-text');

    let debounceTimer = null;

    // Sinkronisasi Slider -> Number Input
    slider.addEventListener('input', (e) => {
      numberInput.value = e.target.value;
      debounceSend(e.target.value);
    });

    // Sinkronisasi Number Input -> Slider
    numberInput.addEventListener('change', (e) => {
      let val = parseFloat(e.target.value);
      if (isNaN(val)) val = 24.0;
      if (val < 16) val = 16;
      if (val > 30) val = 30;
      numberInput.value = val;
      slider.value = val;
      sendTarget(val);
    });

    function setPreset(val) {
      slider.value = val;
      numberInput.value = val;
      sendTarget(val);
    }

    function debounceSend(val) {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        sendTarget(val);
      }, 300);
    }

    // Kirim nilai target suhu ke ESP32
    function sendTarget(val) {
      fetch(`/set?target=${val}`)
        .then(res => res.json())
        .then(data => updateUI(data))
        .catch(err => console.error("Gagal mengirim target:", err));
    }

    // Ambil data sensor secara berkala (tiap 1.5 detik)
    function fetchData() {
      fetch('/data')
        .then(res => res.json())
        .then(data => updateUI(data))
        .catch(err => console.log("Menunggu respon ESP32..."));
    }

    function updateUI(data) {
      valTemp.innerText = (data.temp !== undefined) ? data.temp.toFixed(1) : "--";
      valHum.innerText = (data.humidity !== undefined) ? data.humidity.toFixed(1) : "--";

      // Update slider jika tidak sedang digeser aktif
      if (document.activeElement !== slider && document.activeElement !== numberInput) {
        slider.value = data.target;
        numberInput.value = data.target;
      }

      // Update status AC
      if (data.status === "DINGIN TINGGI") {
        statusBadge.className = "badge badge-cool";
        statusBadge.innerText = "❄️ AC LEVEL TINGGI (HIGH)";
        statusText.innerText = `Suhu ruangan (${data.temp.toFixed(1)}°C) jauh di atas target (${data.target}°C). Kompresor bekerja maksimal.`;
      } else if (data.status === "DINGIN NORMAL") {
        statusBadge.className = "badge badge-cool";
        statusBadge.innerText = "💨 AC LEVEL SEDANG (MED)";
        statusText.innerText = `Suhu ruangan (${data.temp.toFixed(1)}°C) mendekati target (${data.target}°C). Pendinginan normal.`;
      } else {
        statusBadge.className = "badge badge-standby";
        statusBadge.innerText = "🌿 AC STANDBY / HEMAT";
        statusText.innerText = `Suhu ruangan (${data.temp.toFixed(1)}°C) sudah ideal mencapai target (${data.target}°C). Kompresor istirahat.`;
      }
    }

    // Polling data otomatis setiap 1.5 detik
    setInterval(fetchData, 1500);
    fetchData();
  </script>
</body>
</html>
)rawliteral";

// ==================== LOGIKA KONTROL AC OTOMATIS ====================
void kontrolACOtomatis() {
  // Selisih antara suhu aktual dan target suhu
  float delta = currentTemp - targetTemp;

  if (delta >= 2.0) {
    // Suhu masih sangat panas (>= 2°C di atas target)
    acStatus = "DINGIN TINGGI";
    acSpeed = "HIGH";
    digitalWrite(PIN_LED_AC, HIGH);       // Kompresor ON (Maksimal)
    digitalWrite(PIN_LED_STANDBY, LOW);
  } else if (delta > 0.0) {
    // Suhu sedikit di atas target (0 < delta < 2°C)
    acStatus = "DINGIN NORMAL";
    acSpeed = "MED";
    digitalWrite(PIN_LED_AC, HIGH);       // Kompresor ON (Sedang)
    digitalWrite(PIN_LED_STANDBY, LOW);
  } else {
    // Suhu sudah dingin atau sama/lebih rendah dari target
    acStatus = "STANDBY";
    acSpeed = "LOW/IDLE";
    digitalWrite(PIN_LED_AC, LOW);        // Kompresor OFF
    digitalWrite(PIN_LED_STANDBY, HIGH);  // Indikator Standby ON
  }
}

// ==================== UPDATE DISPLAY LCD ====================
void updateLCD() {
  lcd.setCursor(0, 0);
  lcd.print("R:");
  lcd.print(currentTemp, 1);
  lcd.print((char)223); // Simbol Derajat °
  lcd.print("C T:");
  lcd.print(targetTemp, 1);
  lcd.print((char)223);
  lcd.print(" ");

  lcd.setCursor(0, 1);
  if (acStatus == "DINGIN TINGGI") {
    lcd.print("AC:COOL [MAX]   ");
  } else if (acStatus == "DINGIN NORMAL") {
    lcd.print("AC:COOL [MED]   ");
  } else {
    lcd.print("AC:STANDBY/OK   ");
  }
}

// ==================== ENDPOINT WEB SERVER ====================
void handleRoot() {
  server.send_P(200, "text/html", PAGE_MAIN);
}

void handleGetData() {
  String json = "{";
  json += "\"temp\":" + String(currentTemp, 1) + ",";
  json += "\"humidity\":" + String(currentHumidity, 1) + ",";
  json += "\"target\":" + String(targetTemp, 1) + ",";
  json += "\"status\":\"" + acStatus + "\",";
  json += "\"speed\":\"" + acSpeed + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

void handleSetTarget() {
  if (server.hasArg("target")) {
    float newTarget = server.arg("target").toFloat();
    if (newTarget >= 16.0 && newTarget <= 30.0) {
      targetTemp = newTarget;
      kontrolACOtomatis();
      updateLCD();
    }
  }
  handleGetData();
}

// ==================== SETUP ====================
void setup() {
  Serial.begin(115200);
  delay(500);

  // Inisialisasi Pin Output
  pinMode(PIN_LED_AC, OUTPUT);
  pinMode(PIN_LED_STANDBY, OUTPUT);
  digitalWrite(PIN_LED_AC, LOW);
  digitalWrite(PIN_LED_STANDBY, LOW);

  // Inisialisasi Sensor DHT22
  dht.begin();

  // Inisialisasi LCD
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Smart AC ESP32");
  lcd.setCursor(0, 1);
  lcd.print("Memulai WiFi...");

  // Konfigurasi WiFi: Hubungkan ke WiFi & Buat Access Point
  WiFi.mode(WIFI_AP_STA);

  // Jalankan Access Point
  WiFi.softAP(ap_ssid, ap_pass);
  Serial.println("\n[WiFi AP Aktif]");
  Serial.print("Nama AP: "); Serial.println(ap_ssid);
  Serial.print("IP AP   : http://"); Serial.println(WiFi.softAPIP());

  // Hubungkan ke WiFi Station (Wokwi / Router)
  WiFi.begin(sta_ssid, sta_pass);
  Serial.print("Menghubungkan ke WiFi");
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 15) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[WiFi Station Terhubung]");
    Serial.print("IP Client: http://"); Serial.println(WiFi.localIP());
  } else {
    Serial.println("\n[WiFi Station Gagal/Bypass] Menggunakan Access Point.");
  }

  // Routing Web Server
  server.on("/", HTTP_GET, handleRoot);
  server.on("/data", HTTP_GET, handleGetData);
  server.on("/set", HTTP_GET, handleSetTarget);

  server.begin();
  Serial.println("[Web Server Berjalan!]");

  // Tampilan Awal LCD
  lcd.clear();
}

// ==================== LOOP UTAMA ====================
void loop() {
  server.handleClient();

  // Cek apakah ada input angka target dari Serial Monitor (Sangat berguna saat demo di Wokwi)
  if (Serial.available() > 0) {
    String inputStr = Serial.readStringUntil('\n');
    inputStr.trim();
    if (inputStr.length() > 0) {
      float inputTemp = inputStr.toFloat();
      if (inputTemp >= 16.0 && inputTemp <= 30.0) {
        targetTemp = inputTemp;
        Serial.printf(">> [SERIAL] Target suhu diubah menjadi: %.1f C\n", targetTemp);
        kontrolACOtomatis();
        updateLCD();
      } else {
        Serial.println(">> [SERIAL ERROR] Masukkan rentang suhu antara 16.0 sampai 30.0");
      }
    }
  }

  unsigned long currentMillis = millis();
  if (currentMillis - lastSensorRead >= SENSOR_INTERVAL) {
    lastSensorRead = currentMillis;

    float t = dht.readTemperature();
    float h = dht.readHumidity();

    // Validasi pembacaan sensor
    if (!isnan(t) && !isnan(h)) {
      currentTemp = t;
      currentHumidity = h;
    } else {
      Serial.println("[Peringatan] Gagal membaca sensor DHT22!");
    }

    // Jalankan logika kontrol otomatis AC
    kontrolACOtomatis();

    // Update layar LCD
    updateLCD();

    // Debug Serial Monitor
    Serial.printf("Suhu: %.1f C | Kelembapan: %.1f %% | Target: %.1f C | Status: %s (%s)\n",
                  currentTemp, currentHumidity, targetTemp, acStatus.c_str(), acSpeed.c_str());
  }
}

