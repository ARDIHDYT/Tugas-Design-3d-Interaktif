/*
  =============================================================================
  PROYEK SMART AC DI AUTODESK TINKERCAD (ARDUINO UNO + TMP36 + MOTOR DC RPM)
  SISTEM PENGATUR SUHU ADAPTIF BERBASIS OKUPANSI (JUMLAH ORANG)
  -----------------------------------------------------------------------------
  Nama Siswa       : Ardi Hidayat
  Kelas            : XI TELK 4
  Guru Pengampu    : Buk Decy
  Platform         : Autodesk Tinkercad Circuits (NON-IOT / STANDALONE EMBEDDED)
  
  DAFTAR KOMPONEN TINKERCAD:
  1. Arduino Uno R3
  2. Sensor Suhu TMP36        -> Pin Analog A1 (Klik sensor di Tinkercad untuk simulasi suhu)
  3. Potensiometer 10kΩ       -> Pin Analog A0 (Simulasi Jumlah Okupansi 0 s/d 10 Orang)
  4. DC Motor (Motor Kipas)   -> Pin Digital ~6 (PWM Pengatur RPM Putaran Blower)
  5. Relay SPDT               -> Pin Digital 7  (Saklar Daya Kompresor AC)
  6. Piezo Buzzer             -> Pin Digital 8  (Indikator Suara Beep Konfirmasi)
  7. Layar LCD 16x2 (I2C)     -> SDA: Pin A4, SCL: Pin A5 (Alamat I2C: 0x27 atau 0x20)
  =============================================================================
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ==================== ALOKASI PIN ====================
#define PIN_POT A0          // Potensiometer: Simulasi Jumlah Orang (0-10 Orang)
#define PIN_TMP36 A1        // Sensor Suhu TMP36 bawaan Tinkercad
#define PIN_MOTOR_PWM 6     // Motor DC Kipas Blower AC (PWM)
#define PIN_RELAY_COMP 7    // Relay Kompresor AC
#define PIN_BUZZER 8        // Piezo Buzzer

// Inisialisasi Layar LCD 16x2 I2C (Alamat 0x27 atau 0x20)
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ==================== VARIABEL SISTEM ====================
int jumlahOrang = 6;            // Jumlah peserta (0 - 10 Orang)
int lastJumlahOrang = -1;
const float BASE_TEMP = 24.0;   // Suhu dasar saat santai (°C)
float targetTemp = 20.4;        // Target Suhu Adaptif Otomatis (°C)

float currentTemp = 28.0;       // Suhu Ruang Terukur TMP36 (°C)
int currentPWM = 0;             // Nilai PWM (0 - 255)
int currentRPM = 0;             // Nilai RPM Motor DC (0 - 1500 RPM)
String acStatus = "HIGH ";

unsigned long lastSensorRead = 0;
const unsigned long SENSOR_INTERVAL = 1000; // Baca sensor tiap 1 detik

// Bunyi Beep Konfirmasi
void acBeep(int count) {
  for (int i = 0; i < count; i++) {
    digitalWrite(PIN_BUZZER, HIGH);
    delay(40);
    digitalWrite(PIN_BUZZER, LOW);
    if (count > 1) delay(40);
  }
}

// ==================== LOGIKA ADAPTIF: MAKIN BANYAK ORANG MAKIN DINGIN ====================
void hitungTargetAdaptif() {
  if (jumlahOrang == 0) {
    // Ruangan Kosong -> Standby / Hemat Energi
    targetTemp = 25.0;
    acStatus = "STANDBY";
    currentPWM = 0;
    currentRPM = 0;
    digitalWrite(PIN_RELAY_COMP, LOW);
  } 
  else {
    // Rumus Adaptif: Makin banyak orang -> Target makin dingin!
    targetTemp = BASE_TEMP - (jumlahOrang * 0.6);
    if (targetTemp < 18.0) {
      targetTemp = 18.0;
    }

    float delta = currentTemp - targetTemp;

    if (delta >= 4.0 || jumlahOrang >= 9) {
      acStatus = "TURBO";
      currentPWM = 255;
      currentRPM = 1500;
      digitalWrite(PIN_RELAY_COMP, HIGH);
    } 
    else if (delta >= 2.0 || jumlahOrang >= 6) {
      acStatus = "HIGH ";
      currentPWM = 205;
      currentRPM = 1200;
      digitalWrite(PIN_RELAY_COMP, HIGH);
    } 
    else if (delta > 0.0 || jumlahOrang >= 3) {
      acStatus = "MED  ";
      currentPWM = 145;
      currentRPM = 900;
      digitalWrite(PIN_RELAY_COMP, HIGH);
    } 
    else {
      acStatus = "LOW  ";
      currentPWM = 95;
      currentRPM = 600;
      digitalWrite(PIN_RELAY_COMP, HIGH);
    }
  }

  analogWrite(PIN_MOTOR_PWM, currentPWM);
}

// ==================== UPDATE TAMPILAN LCD ====================
void updateLCD() {
  // Baris 1: Okupansi & Target Adaptif
  lcd.setCursor(0, 0);
  if (jumlahOrang == 0) {
    lcd.print("0 Org  [STANDBY]");
  } else {
    if (jumlahOrang < 10) lcd.print(" ");
    lcd.print(jumlahOrang);
    lcd.print("Org  Tgt:");
    lcd.print(targetTemp, 1);
    lcd.print("C");
  }

  // Baris 2: Suhu Aktual TMP36 & Kecepatan Blower
  lcd.setCursor(0, 1);
  lcd.print("R:");
  lcd.print(currentTemp, 1);
  lcd.print("C ");

  if (currentRPM == 0) {
    lcd.print("   0 RPM");
  } else {
    if (currentRPM < 1000) lcd.print(" ");
    lcd.print(currentRPM);
    lcd.print("RPM ");
  }
}

// ==================== BACA SENSOR TMP36 TINKERCAD ====================
float bacaSuhuTMP36() {
  int rawADC = analogRead(PIN_TMP36);
  float voltage = rawADC * (5.0 / 1024.0);
  float tempC = (voltage - 0.5) * 100.0;
  return tempC;
}

// ==================== SETUP ====================
void setup() {
  Serial.begin(9600);

  pinMode(PIN_MOTOR_PWM, OUTPUT);
  pinMode(PIN_RELAY_COMP, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);

  analogWrite(PIN_MOTOR_PWM, 0);
  digitalWrite(PIN_RELAY_COMP, LOW);
  digitalWrite(PIN_BUZZER, LOW);

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print(" SMART CLIMATE  ");
  lcd.setCursor(0, 1);
  lcd.print("ADAPTIVE COOLING");

  delay(1200);
  acBeep(2);
  lcd.clear();

  hitungTargetAdaptif();
  updateLCD();

  Serial.println(F("=========================================================="));
  Serial.println(F("  SIMULASI TINKERCAD SMART AC ADAPTIF - XI TELK 4 ARDI    "));
  Serial.println(F("  - Putar Potensiometer (A0): Simulasi Orang (0-10 Org)   "));
  Serial.println(F("  - Klik Sensor TMP36 (A1): Atur Suhu Ruang               "));
  Serial.println(F("  - Konsep: Makin banyak orang -> Target makin dingin!    "));
  Serial.println(F("=========================================================="));
}

// ==================== LOOP UTAMA ====================
void loop() {
  // 1. Baca Potensiometer sebagai Simulator Okupansi (0 - 10 Orang)
  int potRaw = analogRead(PIN_POT);
  int potPeople = map(potRaw, 0, 1020, 0, 10);
  potPeople = constrain(potPeople, 0, 10);

  if (potPeople != lastJumlahOrang) {
    jumlahOrang = potPeople;
    lastJumlahOrang = potPeople;
    acBeep(1);
    hitungTargetAdaptif();
    updateLCD();

    Serial.print(F("[OKUPANSI] Jumlah Orang: "));
    Serial.print(jumlahOrang);
    Serial.print(F(" Org -> Target Suhu: "));
    Serial.print(targetTemp, 1);
    Serial.print(F(" °C | Blower: "));
    Serial.print(currentRPM);
    Serial.println(F(" RPM"));
  }

  // 2. Baca Sensor Suhu TMP36 Berkala
  unsigned long now = millis();
  if (now - lastSensorRead >= SENSOR_INTERVAL) {
    lastSensorRead = now;

    float t = bacaSuhuTMP36();
    if (t >= -10.0 && t <= 60.0) {
      currentTemp = t;
    }

    hitungTargetAdaptif();
    updateLCD();

    Serial.print(F("TMP36: ")); Serial.print(currentTemp, 1);
    Serial.print(F("C | Okupansi: ")); Serial.print(jumlahOrang);
    Serial.print(F(" Org | Target: ")); Serial.print(targetTemp, 1);
    Serial.print(F("C | Blower: ")); Serial.print(currentRPM);
    Serial.print(F(" RPM | Kompresor: ")); 
    Serial.println(currentRPM > 0 ? "ON" : "OFF");
  }
}
