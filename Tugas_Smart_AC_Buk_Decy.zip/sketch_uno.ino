/*
  =============================================================================
  PROYEK SMART AC ARDUINO UNO + DHT22 + MOTOR BLOWER RPM (NON-IOT)
  SISTEM PENGATUR SUHU ADAPTIF BERBASIS OKUPANSI (JUMLAH ORANG RAPAT)
  -----------------------------------------------------------------------------
  Mata Pelajaran   : Pemrograman Sistem Tertanam & Mikrokontroler
  Kelas            : XI TELK 4
  Penyusun         : Ardi Hidayat
  Guru Pengampu    : Buk Decy
  
  DESKRIPSI SISTEM & KONSEP KERJA:
  1. Beban Kalor Okupansi: Setiap manusia menghasilkan kalor tubuh (~100 Watt).
     Makin banyak orang di ruang rapat, udara semakin cepat panas dan gerah.
  2. Logika Adaptif (Adaptive Setpoint):
     - Saat Ruangan Kosong (0 Orang)   -> AC STANDBY (0 RPM, Kompresor OFF).
     - Sedikit Orang (1 - 2 Orang)     -> Target 23.4°C - 22.8°C (LOW COOL: 600 RPM).
     - Sedang (3 - 5 Orang)            -> Target 22.2°C - 21.0°C (MED COOL: 900 RPM).
     - Rapat Ramai (6 - 8 Orang)       -> Target 20.4°C - 19.2°C (HIGH COOL: 1.200 RPM).
     - Rapat Penuh (9 - 10 Orang)      -> Target 18.0°C (TURBO COOL: 1.500 RPM Maksimal).
  3. Aktuator:
     - Motor DC Kipas Blower AC dikendalikan kecepatannya (RPM) presisi via PWM.
     - Relay 5V mengendalikan daya kompresor pendingin.
     - Potensiometer A0 bertindak sebagai Simulator Jumlah Orang (0 s/d 10 Orang).
  =============================================================================
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// ==================== ALOKASI PIN ====================
#define PIN_POT A0          // Potensiometer: Simulator Jumlah Orang (0-10 Orang)
#define DHTPIN 2            // Pin Data Sensor DHT22 (Suhu & Kelembapan Ruang)
#define DHTTYPE DHT22

#define PIN_MOTOR_PWM 6     // Pin PWM Pengatur Kecepatan Motor Blower AC (RPM)
#define PIN_RELAY_COMP 7    // Pin Relay Saklar Daya Kompresor AC
#define PIN_BUZZER 8        // Pin Buzzer Beep Konfirmasi
#define PIN_LED_MOTOR 9     // Indikator LED Motor Berputar (Visual PWM)

// Inisialisasi Objek Sensor & LCD
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ==================== VARIABEL SISTEM ====================
int jumlahOrang = 6;            // Jumlah peserta rapat default (0 - 10 Orang)
int lastJumlahOrang = -1;
const float BASE_TEMP = 24.0;   // Suhu dasar ruangan santai (°C)
float targetTemp = 20.4;        // Target Suhu Adaptif yang Dihitung Otomatis (°C)

float currentTemp = 27.5;       // Suhu Aktual Ruangan dari DHT22 (°C)
float currentHum = 60.0;        // Kelembapan Ruangan (%)

int currentPWM = 0;             // Nilai PWM Motor Blower (0 - 255)
int currentRPM = 0;             // Nilai RPM Motor Blower (0 - 1500 RPM)
String acStatus = "HIGH ";

unsigned long lastSensorRead = 0;
const unsigned long SENSOR_INTERVAL = 1500; // Baca sensor tiap 1.5 detik

// Bunyi Beep Konfirmasi
void acBeep(int count) {
  for (int i = 0; i < count; i++) {
    digitalWrite(PIN_BUZZER, HIGH);
    delay(35);
    digitalWrite(PIN_BUZZER, LOW);
    if (count > 1) delay(35);
  }
}

// ==================== LOGIKA ADAPTIF: MAKIN BANYAK ORANG MAKIN DINGIN ====================
void hitungTargetAdaptif() {
  if (jumlahOrang == 0) {
    // KONDISI 1: RUANGAN KOSONG (0 ORANG) -> STANDBY / HEMAT ENERGI
    targetTemp = 25.0;
    acStatus = "STANDBY";
    currentPWM = 0;                 // Motor Kipas Mati
    currentRPM = 0;
    digitalWrite(PIN_RELAY_COMP, LOW);  // Kompresor OFF
  } 
  else {
    // KONDISI 2: ADA ORANG -> HITUNG TARGET SUHU ADAPTIF
    // Rumus: Setiap 1 orang menurunkan setpoint 0.6°C (Makin banyak orang makin dingin!)
    targetTemp = BASE_TEMP - (jumlahOrang * 0.6);
    if (targetTemp < 18.0) {
      targetTemp = 18.0;            // Batas dingin maksimal termostat 18.0°C
    }

    // Evaluasi selisih antara Suhu Aktual (DHT22) dengan Target Adaptif
    float delta = currentTemp - targetTemp;

    if (delta >= 4.0 || jumlahOrang >= 9) {
      // RAPAT PENUH / SANGAT PANAS -> TURBO COOL
      acStatus = "TURBO";
      currentPWM = 255;             // Daya Penuh 100%
      currentRPM = 1500;            // Putaran Maksimal 1.500 RPM
      digitalWrite(PIN_RELAY_COMP, HIGH);
    } 
    else if (delta >= 2.0 || jumlahOrang >= 6) {
      // RAPAT RAMAI (6-8 ORANG) -> HIGH COOL
      acStatus = "HIGH ";
      currentPWM = 205;             // Daya ~80%
      currentRPM = 1200;            // Putaran Kencang 1.200 RPM
      digitalWrite(PIN_RELAY_COMP, HIGH);
    } 
    else if (delta > 0.0 || jumlahOrang >= 3) {
      // RAPAT SEDANG (3-5 ORANG) -> MEDIUM COOL
      acStatus = "MED  ";
      currentPWM = 145;             // Daya ~57%
      currentRPM = 900;             // Putaran Sedang 900 RPM
      digitalWrite(PIN_RELAY_COMP, HIGH);
    } 
    else {
      // SEDIKIT ORANG (1-2 ORANG) -> LOW COOL
      acStatus = "LOW  ";
      currentPWM = 95;              // Daya ~37%
      currentRPM = 600;             // Putaran Halus 600 RPM
      digitalWrite(PIN_RELAY_COMP, HIGH);
    }
  }

  // Terapkan kecepatan ke motor blower melalui sinyal analog PWM
  analogWrite(PIN_MOTOR_PWM, currentPWM);
  analogWrite(PIN_LED_MOTOR, currentPWM); // Visualisasi nyala LED motor
}

// ==================== UPDATE TAMPILAN LCD 16x2 ====================
void updateLCD() {
  // Baris 1: Jumlah Peserta Rapat & Target Suhu Adaptif
  lcd.setCursor(0, 0);
  if (jumlahOrang == 0) {
    lcd.print("0 Org  [STANDBY]");
  } else {
    if (jumlahOrang < 10) lcd.print(" ");
    lcd.print(jumlahOrang);
    lcd.print("Org  Tgt:");
    lcd.print(targetTemp, 1);
    lcd.print("C");
  }

  // Baris 2: Suhu Aktual Ruangan (DHT22) & Kecepatan Putaran Blower
  lcd.setCursor(0, 1);
  lcd.print("R:");
  lcd.print(currentTemp, 1);
  lcd.print("C ");

  if (currentRPM == 0) {
    lcd.print("   0 RPM");
  } else {
    if (currentRPM < 1000) lcd.print(" ");
    lcd.print(currentRPM);
    lcd.print("RPM ");
  }
}

// ==================== SETUP ====================
void setup() {
  Serial.begin(9600);

  // Konfigurasi Pin Digital
  pinMode(PIN_MOTOR_PWM, OUTPUT);
  pinMode(PIN_RELAY_COMP, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LED_MOTOR, OUTPUT);

  analogWrite(PIN_MOTOR_PWM, 0);
  digitalWrite(PIN_RELAY_COMP, LOW);
  digitalWrite(PIN_BUZZER, LOW);
  analogWrite(PIN_LED_MOTOR, 0);

  // Inisialisasi LCD 16x2 I2C
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print(" SMART CLIMATE  ");
  lcd.setCursor(0, 1);
  lcd.print("ADAPTIVE COOLING");

  // Inisialisasi Sensor DHT22
  dht.begin();
  delay(1200);

  acBeep(2);
  lcd.clear();

  // Inisialisasi perhitungan awal
  hitungTargetAdaptif();
  updateLCD();

  Serial.println(F("=========================================================="));
  Serial.println(F("  SMART AC ADAPTIF OKUPANSI - XI TELK 4 ARDI HIDAYAT     "));
  Serial.println(F("  - Putar Potensiometer (A0): Simulasi Jumlah Orang (0-10)"));
  Serial.println(F("  - Ketik '0'..'10' atau '+' / '-' di Serial Monitor      "));
  Serial.println(F("  - Konsep: Makin banyak orang -> Target makin dingin!    "));
  Serial.println(F("=========================================================="));
}

// ==================== LOOP UTAMA ====================
void loop() {
  // 1. Baca Potensiometer sebagai Simulator Jumlah Orang (0 s/d 10 Orang)
  int potRaw = analogRead(PIN_POT);
  int potPeople = map(potRaw, 0, 1020, 0, 10);
  potPeople = constrain(potPeople, 0, 10);

  if (potPeople != lastJumlahOrang) {
    jumlahOrang = potPeople;
    lastJumlahOrang = potPeople;
    acBeep(1); // Beep konfirmasi perubahan orang
    hitungTargetAdaptif();
    updateLCD();

    Serial.print(F("[OKUPANSI] Jumlah Peserta: "));
    Serial.print(jumlahOrang);
    Serial.print(F(" Orang -> Target Suhu Adaptif: "));
    Serial.print(targetTemp, 1);
    Serial.print(F(" °C | Mode: "));
    Serial.print(acStatus);
    Serial.print(F(" | RPM: "));
    Serial.println(currentRPM);
  }

  // 2. Baca Input Serial Monitor (Opsi Pengujian Praktis dari Laptop)
  if (Serial.available() > 0) {
    String inputStr = Serial.readStringUntil('\n');
    inputStr.trim();
    if (inputStr.length() > 0) {
      if (inputStr == "+") {
        if (jumlahOrang < 10) jumlahOrang++;
      } else if (inputStr == "-") {
        if (jumlahOrang > 0) jumlahOrang--;
      } else {
        int val = inputStr.toInt();
        if (val >= 0 && val <= 10) {
          jumlahOrang = val;
        }
      }
      lastJumlahOrang = jumlahOrang;
      acBeep(1);
      hitungTargetAdaptif();
      updateLCD();

      Serial.print(F("[SERIAL INPUT] Okupansi: "));
      Serial.print(jumlahOrang);
      Serial.print(F(" Orang -> Target: "));
      Serial.print(targetTemp, 1);
      Serial.print(F(" °C | Blower: "));
      Serial.print(currentRPM);
      Serial.println(F(" RPM"));
    }
  }

  // 3. Baca Sensor DHT22 Secara Berkala (Tiap 1.5 Detik)
  unsigned long now = millis();
  if (now - lastSensorRead >= SENSOR_INTERVAL) {
    lastSensorRead = now;

    float t = dht.readTemperature();
    float h = dht.readHumidity();

    if (!isnan(t) && !isnan(h)) {
      currentTemp = t;
      currentHum = h;
    }

    // Perbarui evaluasi adaptif & LCD
    hitungTargetAdaptif();
    updateLCD();

    // Log Telemetri ke Serial Monitor
    Serial.print(F("Okupansi: ")); Serial.print(jumlahOrang);
    Serial.print(F(" Org | Suhu: ")); Serial.print(currentTemp, 1);
    Serial.print(F("C | Tgt: ")); Serial.print(targetTemp, 1);
    Serial.print(F("C | Status: ")); Serial.print(acStatus);
    Serial.print(F(" | Blower: ")); Serial.print(currentRPM);
    Serial.print(F(" RPM | Kompresor: ")); 
    Serial.println(currentRPM > 0 ? "ON" : "OFF");
  }
}
